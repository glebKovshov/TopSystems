from PythonAPIParcer import parse_python_api
from RGKParcer import parse_cpp_header
import os
from pathlib import Path
from time import sleep

def get_folders(directory):
    #Функция для получения всех папок в указанной директории
    subfolders = []
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isdir(item_path):
            subfolders.append(item_path)
    return subfolders

def find_path(dir, func):
    #Функция поиска полоного пути до файла Pyhton API по имени класса заголовка
    for root, dirs, files in os.walk(dir):
        for file in files:
                name = file.replace(".cpp", "")
                name = name[name.rfind(".")+1:]
                if (name == func):
                    return root+"\\"+file

def find_missed_methods(CppSource="C:\RGK\install\include\RGK", PythonSource="C:\\Users\\Глеб\\Documents\\ps", ReportPath="C:\\ParseResult\\report\\"):
    #Функция поиска пропущенных методов
    paths_cpp = get_folders(CppSource)
    PassFolders = ["C:\RGK\install\include\RGK\.vs"]
    TargetFolders = ["C:\\RGK\\install\\include\\RGK\\Generators", "C:\\RGK\\install\\include\\RGK\\Utils", "C:\\RGK\\install\\include\\RGK\\Topols", "C:\\RGK\\install\\include\\RGK\\Geometry"]
    
    for path in paths_cpp:
        #Ищем только в указанных папках
        if ((path not in PassFolders) and (path in TargetFolders)):
            
            #Получаем название текущей папки
            folder = path[path.rfind("\\")+1:]
            #Создаем файл отчета с названием папки (класса)
            report = open(ReportPath+folder+".txt", "w")

            #Проходим по всем .h файлам папки
            for file in Path(path).rglob('*.h'):
                
                #Получаем методы парсера C++ заголовков
                methods_cpp = parse_cpp_header(file)
                #Получаем название файла
                file = str(file)[str(file).rfind("\\")+1:]
                #Ищем файл Pyhton API по названию
                python_path = find_path(PythonSource+"\\"+folder, file.replace(".h", ""))
                
                try: 
                    #Получаем полное корректное имя файла
                    filename = python_path[python_path.rfind("\\")+1:]
                    #Записываем его название в отчет
                    report.write(f'FILENAME: {filename}\n')
                    #Получаем методы Pyhton API
                    methods_python = parse_python_api(python_path)
                    #Счетчик пропущенных методов
                    miss = 0

                    for m_cpp in methods_cpp:
                        find = False
                        #Берем метод и проходимся по всем иным методам
                        for m_python in methods_python:
                            if (m_cpp["method_name"] == m_python["method_name"]): 
                                find = True
                                break
                        
                        #Если не найдено, то добавляем в отчет пропущенный метод
                        if not (find):
                            miss+=1
                            report.write(f"{miss}) MISS: {m_cpp['method_name']}()\n")

                    #В конце пишем сколько всего было пропущено
                    report.write(f"MISSED: {miss}\n")

                #Если не удалось найти файл Pyhton API, то выводим ошибку, что файла с именем, как у C++, не существует
                except:
                    report.write(f"FILENAME CPP {file}\n")
                    report.write("FILE IS NOT EXIST\n")

                #Разделитель строк
                report.write("#"*50+"\n")
            
            print(f'FOLDER {folder} PASSED SUCCESSFULLY')
            report.close()
