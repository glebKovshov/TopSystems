from pathlib import Path
import os

def find_method_name(method):
    end = method.index("(")
    method_name = method[method.rindex(" ", 0, end)+1:end]
    return method_name

def find_return_type(method):
    end = method.index("(")
    method = method[:end]
    #Убираем название метода и оставляем только возвращаемый тип
    return_type = method.split(" ")[:-1] 
    #Возвращаем последний элемент разбитой на части строки
    return "".join(return_type[len(return_type)-1])

def find_arguments(method):
    start = method.index("(")+1
    end = method.index(")")
    if not (end-start): return None
    #отделяем основную часть с аргументами
    method = method[start:end]
    #разбиваем аргументы на части
    arguments = method.split(", ")
    for i in range(0, len(arguments)):
        #Вытаскиваем только тип данных
        arguments[i] = " ".join(arguments[i].split(" ")[:-1])
    return arguments

def find_features(method):
    if (method.split(" ")[0] == "static"): return "static"
    #Если определяется константный метод, то синтактически он заключен между именем и описанием метода
    start = method.index(")")+1
    #Константный метод может быть либо с описанием, либо - без
    if (method[-1] == "}" and "const" in method[start:method.index("{")]): return "const"
    if (method[-1] == ";" and "const" in method[start:method.index(";")]): return "const"
    return None

def is_classname_include(line, prefix):

    #Функция, определяющая является ли переданная функция конструктором или деструктором

    #Дестуктор или констуктор всегда перед скобками
    class_name = prefix[prefix.rfind(":")+1:]

    #Отделяем имя и возвращаемый тип данных от скобок
    func = line[:line.find("(")].split(" ")

    if (len(func) > 1):
        if (class_name in func[1]): return True
        return False
    if (class_name in func[0]): return True

    return False

def parse_cpp_header(filename): # -> list methods

    #Функция парсинга CPP .h файла для нахождения функций классов

    #Открываем файл на чтение
    file = open(filename, "r", encoding="utf-8") 
    #Исходный префикс
    prefix = "" 
    #Символы, которые пропускаются при перебори строк файла
    passChar = ["#", "/", "\n", "\ufeff"] 
    #Возвращаемые методы (результат парсера)
    methods = list()
    #Флаг для игнорирования чтения строк
    ignore = False

    #Цикл перебора всех строк в тексте файла
    for line in file:
        try:
            #Избавляемся в начале от пробелов или табуляци
            while (line[0] == " "): line = line[1:]
            if (line[0] == "\t"): line = line.replace("\t", "")

            #Если в начале строки имеются симвлолы, с которыми мы работать не будем, то переходим к следующей строке
            if ((line[0] in passChar) or ("typedef" in line)): continue
            
            #Убираем все сноски для удобства
            if ("\n" in line): line = line.replace("\n", "")

            #Если нашли имя пространства имен, то записываем его в самое начало префикса
            if (line.split(" ")[0] == "namespace"):
                prefix = line.split(" ")[1]
                continue
            
            #Если есть inline, то избегаем удаления последнего элемента префикса, а также не обрабатываем тело, если 
            if ("inline" in line or "template" in line):
                ignore = True
                continue

            #Если нашли строку с описанием имени класса или перечисления, то записываем его в префикс
            if ("class" in line or "enum" in line or "struct" in line):
                #Если класс заканчивается на ';', то в нем ничего нет
                if (line[-1] == ";"): continue
                #В других случаях записываем имя класса
                else:
                    prefix+=f'::{line.split(" ")[2]}' 
                    continue

            #Удаляем последний элемент префикса при закрытии скобки в файле
            if (line[0] == "}"):
                if (ignore): ignore = False
                else: prefix = prefix[:prefix.rfind("::")]
                continue

            #Проверяем есть ли скобки в строке, и не имеет ли строка имени конечного элемента префикса (конструктор или деструктор класса)
            if (("(" in line) and (")" in line) and not (ignore) and not (is_classname_include(line, prefix)) and not ("operator" in line) and not("ADD" in line)):
                method = line
                #Нахождение имени, типа и аргументов метода
                method_name = find_method_name(method)
                return_type = find_return_type(method)
                arguments = find_arguments(method)
                #если метод константный (const) или статичный (static), то возвращает const или static, в ином случае - None
                feature = find_features(method)
                
                result = {
                    "prefix":prefix,
                    "method_name":method_name,
                    "return_type":return_type,
                    "arguments":arguments,
                    "feature":feature}
                
                methods.append(result)
        except:
            pass
    
    file.close()
    return methods

#def get_folders(directory):
    subfolders = []
    for item in os.listdir(directory):
        item_path = os.path.join(directory, item)
        if os.path.isdir(item_path):
            subfolders.append(item_path)
    return subfolders

#def search_and_write_in_file(RGKPath="C:\RGK\install\include\RGK"):

    paths = get_folders(RGKPath)
    PassFolders = [".vs"]

    for path in paths:
        if (path == "C:\RGK\install\include\RGK\Generators"):
            path = Path(path)

            #Создаем папку, где будут храниться файлы
            dirname = str(path)[str(path).rindex("\\")+1:]
            os.makedirs("C:\\ParseResult\\cpp\\"+dirname, exist_ok=True)

            for p in path.rglob('*.h'):

                #Создаем файл в созданной директории
                filename = str(p)[str(p).rindex("\\")+1:]
                file = open("C:\\ParseResult\\cpp\\"+dirname+"\\"+filename+".txt", "w")

                #Получаем методы парсера
                methods_cpp = parse_cpp_header(p)

                #Полный путь файла
                file.write(str(p)+"\n")
                #Методы
                for method in methods_cpp:
                    file.write(method+"\n")