from RGKParcer import parse_cpp_header
from PythonAPIParcer import parse_python_api
from CheckingFiles import find_missed_methods

#Указать пути до источников
PythonSource = "C:\\Users\\Глеб\\Documents\\ps"
RGKSource = "C:\\RGK\\install\\include\\RGK"
#Указать путь до места, где будет храниться отчет
ReportPath = "C:\\ParseResult\\report"

find_missed_methods(RGKSource, PythonSource, ReportPath)