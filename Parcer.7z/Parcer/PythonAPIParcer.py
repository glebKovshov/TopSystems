def parse_python_api(filename): # -> list methods
    
    #Открываем файл на чтение
    file = open(filename, "r", encoding="utf-8") 

    prefix = "RGK"
    modulename = ""
    passChar = ["#", "\n"]
    methods = []

    for line in file:
        if (line[0] in passChar): continue
        while (line[0] == " "): line = line[1:]
        if (line[0] == "\t"): line = line.replace("\t", "")
        if ("\n" in line): line = line.replace("\n", "")

        if ("IMPORT_PY_MODULE" in line):
            modulename = line[line.find("(")+1:line.find(")")]
            prefix+=f'::{modulename}'
            continue
        
        if ("BEGIN_PY_CLASS_METHODS" in line):
            classname = line[line.find("(")+1:line.find(")")]
            prefix+=f'::{classname}'
            continue
        
        if ("END_PY_METHODS" in line):
            prefix = prefix[:prefix.find(modulename)+len(modulename)]
            continue
        
        if (("ADD_PY_METHOD" in line) or ("ADD_PY_CONST_METHOD" in line) or ("ADD_PY_STATIC_METHOD" in line)):
            method = line[line.find("(")+1:line.find(")")].split(", ")

            feature = ""
            if ("CONST" in line): feature = "const"
            elif ("STATIC" in line): feature = "static"
            else: feature = "None"

            result = {
                    "prefix":prefix,
                    "method_name":method[0],
                    "return_type":method[1],
                    "arguments":method[2:],
                    "feature":feature}
            
            methods.append(result)

    file.close()
    return methods